// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCX8EeOpBKgETur_MLuL0BFpS-GBTGrLRQ",
  authDomain: "socialmedia-220f4.firebaseapp.com",
  projectId: "socialmedia-220f4",
  storageBucket: "socialmedia-220f4.appspot.com",
  messagingSenderId: "1017867411905",
  appId: "1:1017867411905:web:8389408c46ef991067cf40",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export default app;
