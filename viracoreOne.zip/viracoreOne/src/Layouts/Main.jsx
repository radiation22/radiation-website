import React from "react";
import All from "../components/Home/All";

const Main = () => {
  return (
    <div>
      <All></All>
    </div>
  );
};

export default Main;
